// simple example of accessing an array element

#include <stdio.h>

int x[10];

int main(void) {
    x[3] = 17;
}
